require 'puppet/util/feature'

Puppet.features.add(:LenovoCheflib, :libs => ['LenovoCheflib'])

